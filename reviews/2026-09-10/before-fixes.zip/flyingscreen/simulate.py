"""
The nonlinear simulator: integrate the coupled ODEs and account for energy.

Rather than integrating a whole work session step by step, the simulator
runs a representative window of the mission at full fidelity, measures the
mean electrical power over that window once the transient has decayed, and
extrapolates to the mission duration:

    E_mission = P_mean * t_f

This is the honest version of E = P t.  P_mean now comes from the actual
controller working against actual drag, gusts and human motion, so it is
strictly larger than the ideal hover power, and by an amount the model
computes rather than guesses.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import numpy as np

from . import mission as mission_mod
from .params import derived
from .control import CascadedController, screen_tilt_error
from .dynamics import (Vehicle, build_vehicle, derivatives, initial_state,
                       normalize_quat, quat_to_rot, euler_from_rot,
                       electrical_power)


@dataclass
class SimResult:
    ok: bool
    reason: str = ""
    t: List[float] = field(default_factory=list)
    telemetry: Dict[str, List[float]] = field(default_factory=dict)
    trajectory: Dict[str, List[List[float]]] = field(default_factory=dict)
    P_mean: float = 0.0
    P_hover_ref: float = 0.0        # steady hover of this same rotor
    P_ideal_lumped: float = 0.0     # what the closed-form layer assumes
    P_peak: float = 0.0
    energy_window: float = 0.0
    E_mission: float = 0.0
    e_track_rms: float = 0.0     # against the reference the controller was given
    e_track_max: float = 0.0
    e_lag_rms: float = 0.0       # against where the screen ideally belongs
    e_lag_max: float = 0.0
    tilt_rms_deg: float = 0.0
    tilt_max_deg: float = 0.0
    screen_tilt_rms_deg: float = 0.0
    screen_tilt_max_deg: float = 0.0
    saturation_fraction: float = 0.0
    keepout_fraction: float = 0.0   # time the reference was pushed off the head
    ref_accel_max: float = 0.0      # peak acceleration the mission asks for [m/s^2]
    lam_needed: float = 0.0         # thrust margin that peak alone implies   [-]
    min_human_distance: float = 0.0
    soc_end: float = 1.0
    endurance_est: float = 0.0
    overhead: float = 1.0          # P_mean / ideal hover power
    warnings: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        d = dict(self.__dict__)
        return d


def simulate_flight(p: Dict[str, float], m: float, m_bat: Optional[float] = None,
                    mission_kind: str = "pacing", t_window: float = 30.0,
                    dt: float = 0.004, sample_hz: float = 25.0,
                    settle: float = 3.0, seed: int = 12345,
                    veh: Optional[Vehicle] = None,
                    governor: Optional[Dict[str, float]] = None) -> SimResult:
    """
    Integrate a window of the mission with RK4 at fixed step.

    Passing `governor` (a dict of v_max and a_max) puts a rate limited
    reference between the human and the controller, which is what a real
    product does instead of chasing a face rigidly.
    """
    if veh is None:
        veh = build_vehicle(p, m, m_bat)
    human = mission_mod.make_human(p, mission_kind)
    wind = mission_mod.Wind(p, t_window, seed=seed)
    ctrl = CascadedController(p, veh)

    ref0 = mission_mod.reference(p, human, 0.0)
    x = initial_state(veh, np.asarray(ref0["r"], dtype=float),
                      yaw0=float(ref0["yaw"]),
                      v0=np.asarray(ref0["v"], dtype=float))
    gov = None
    if governor:
        gov = mission_mod.ReferenceGovernor(p, ref0["r"], **governor)
        gov.v = np.asarray(ref0["v"], dtype=float).copy()
    N = veh.N
    n_steps = max(int(round(t_window / dt)), 1)
    stride = max(int(round(1.0 / (sample_hz * dt))), 1)

    ts: List[float] = []
    tel: Dict[str, List[float]] = {k: [] for k in
                                   ("P", "soc", "e_track", "tilt_deg",
                                    "screen_tilt_deg", "T", "thrust_ratio",
                                    "omega_mean", "v_speed", "sat")}
    traj = {"r": [], "r_h": [], "r_d": [], "euler": []}

    P_acc, P_cnt, P_peak = 0.0, 0, 0.0
    e_acc, e_cnt, e_max = 0.0, 0, 0.0
    eraw_acc, eraw_max = 0.0, 0.0
    tilt_acc, tilt_max = 0.0, 0.0
    st_acc, st_max = 0.0, 0.0
    sat_cnt = 0
    blocked_cnt = 0
    d_min = float("inf")
    energy0 = x[13 + N]
    zero3 = np.zeros(3)

    def rhs(tt: float, xx: np.ndarray, u_om, u_g) -> np.ndarray:
        return derivatives(veh, tt, xx, u_om, u_g, wind(tt), zero3)

    # The person's head, not their feet: the trajectory generator reports a
    # ground reference, and the thing we must not hit is at eye level.
    head_offset = np.array([0.0, 0.0, float(p["standoff_z"])])
    a_ref_max = 0.0
    for k in range(n_steps):
        t = k * dt
        ref = mission_mod.reference(p, human, t)
        r_wanted = np.asarray(ref["r"], dtype=float)
        r_head = np.asarray(ref["human"], dtype=float) + head_offset
        if gov is not None:
            # The rotors must never be commanded inside the safe distance of
            # the head, so the keep-out radius is the safe distance plus the
            # whole reach of the machine.
            gov.step(ref["r"], ref["v"], dt,
                     keep_out=(r_head, float(p["d_safe"]) + veh.reach))
            ref = dict(ref, r=gov.r.copy(), v=gov.v.copy(), a=gov.a.copy())
            if gov.blocked:
                blocked_cnt += 1
        a_ref_max = max(a_ref_max, float(np.linalg.norm(ref["a"])))
        out = ctrl(t, x, ref, dt)
        u_om, u_g = out.Om_cmd, out.tau_g

        k1 = rhs(t, x, u_om, u_g)
        k2 = rhs(t + 0.5 * dt, x + 0.5 * dt * k1, u_om, u_g)
        k3 = rhs(t + 0.5 * dt, x + 0.5 * dt * k2, u_om, u_g)
        k4 = rhs(t + dt, x + dt * k3, u_om, u_g)
        x = normalize_quat(x + (dt / 6.0) * (k1 + 2.0 * k2 + 2.0 * k3 + k4))

        if not np.all(np.isfinite(x)):
            return SimResult(ok=False, reason="integration diverged: the controller "
                                              "lost the vehicle at t = %.2f s" % t)
        r = x[0:3]
        err = float(np.linalg.norm(np.asarray(ref["r"]) - r))
        # What the reader sees: distance from where the screen ideally
        # belongs, which the governor deliberately lets go during a turn.
        err_raw = float(np.linalg.norm(r_wanted - r))
        if err > 25.0:
            return SimResult(ok=False, reason="tracking error exceeded 25 m at t = %.2f s: "
                                              "the design cannot follow this mission" % t)

        P = electrical_power(veh, x[13:13 + N])
        R = quat_to_rot(x[6:10])
        tilt = math.acos(max(-1.0, min(1.0, float(R[2, 2]))))
        st = screen_tilt_error(veh, x)
        # Distance to the nearest *blade tip*, not to the vehicle centre.
        # Measuring to the centre flatters the design by the entire reach of
        # the machine, which for this one is 0.63 m.
        d_min = min(d_min, float(np.linalg.norm(r - r_head)) - veh.reach)

        if t >= settle:
            P_acc += P; P_cnt += 1
            P_peak = max(P_peak, P)
            e_acc += err * err; e_cnt += 1; e_max = max(e_max, err)
            eraw_acc += err_raw * err_raw
            eraw_max = max(eraw_max, err_raw)
            tilt_acc += tilt * tilt; tilt_max = max(tilt_max, tilt)
            st_acc += st * st; st_max = max(st_max, st)
            if out.saturated:
                sat_cnt += 1

        if k % stride == 0:
            ts.append(t)
            tel["P"].append(P)
            tel["soc"].append(float(x[13 + N] / veh.E_max) if veh.E_max > 0 else 0.0)
            tel["e_track"].append(err)
            tel["tilt_deg"].append(math.degrees(tilt))
            tel["screen_tilt_deg"].append(math.degrees(st))
            T = float(veh.alloc[0] @ np.clip(x[13:13 + N], 0, None) ** 2)
            tel["T"].append(T)
            tel["thrust_ratio"].append(T / (veh.m * veh.g))
            tel["omega_mean"].append(float(np.mean(x[13:13 + N])))
            tel["v_speed"].append(float(np.linalg.norm(x[3:6])))
            tel["sat"].append(1.0 if out.saturated else 0.0)
            traj["r"].append([float(v) for v in r])
            traj["r_h"].append([float(v) for v in np.asarray(ref["human"])])
            traj["r_d"].append([float(v) for v in np.asarray(ref["r"])])
            roll, pitch, yaw = euler_from_rot(R)
            traj["euler"].append([math.degrees(roll), math.degrees(pitch),
                                  math.degrees(yaw)])

    P_mean = P_acc / max(P_cnt, 1)
    d = derived(p)
    # Baseline is steady hover of *this* rotor, so the overhead measures what
    # the mission costs above hovering rather than a mismatch between the
    # lumped figure of merit and the one the blade model produces.
    om_hover = math.sqrt(veh.m * veh.g / (veh.N * veh.k_T))
    P_hover_ref = veh.N * veh.k_P * om_hover ** 3 / veh.eta + d.P_aux
    P_ideal_lumped = (m * veh.g) ** 1.5 / (float(p["FM"]) * float(p["eta"]) *
                                           math.sqrt(2.0 * veh.rho * d.A)) + d.P_aux
    t_f = float(p["t_f"])
    E_mission = P_mean * t_f
    energy_window = float(energy0 - x[13 + N])

    res = SimResult(
        ok=True, t=ts, telemetry=tel, trajectory=traj, P_mean=P_mean,
        P_hover_ref=P_hover_ref, P_ideal_lumped=P_ideal_lumped,
        P_peak=P_peak, energy_window=energy_window,
        E_mission=E_mission,
        e_track_rms=math.sqrt(e_acc / max(e_cnt, 1)), e_track_max=e_max,
        e_lag_rms=math.sqrt(eraw_acc / max(e_cnt, 1)), e_lag_max=eraw_max,
        tilt_rms_deg=math.degrees(math.sqrt(tilt_acc / max(e_cnt, 1))),
        tilt_max_deg=math.degrees(tilt_max),
        screen_tilt_rms_deg=math.degrees(math.sqrt(st_acc / max(e_cnt, 1))),
        screen_tilt_max_deg=math.degrees(st_max),
        saturation_fraction=sat_cnt / max(e_cnt, 1),
        ref_accel_max=a_ref_max,
        keepout_fraction=blocked_cnt / max(n_steps, 1),
        lam_needed=math.hypot(veh.g, a_ref_max) / veh.g,
        min_human_distance=d_min,
        soc_end=max(0.0, 1.0 - E_mission / veh.E_max) if veh.E_max > 0 else 0.0,
        endurance_est=veh.E_max / max(P_mean, 1e-9),
        overhead=P_mean / max(P_hover_ref, 1e-9),
    )
    if res.saturation_fraction > 0.02:
        res.warnings.append(
            "motors saturate %.0f percent of the time: this mission peaks at %.1f m/s^2, "
            "which needs a thrust margin of at least %.2f before any control authority "
            "is left over, against the %.2f set"
            % (100.0 * res.saturation_fraction, res.ref_accel_max,
               res.lam_needed, float(p["lam"])))
    if res.screen_tilt_max_deg > float(p["theta_readable"]):
        res.warnings.append("screen tilts %.1f deg, beyond the %.0f deg readability limit"
                            % (res.screen_tilt_max_deg, float(p["theta_readable"])))
    if res.min_human_distance < float(p["d_safe"]):
        res.warnings.append("closest approach %.2f m violates the %.2f m safety distance"
                            % (res.min_human_distance, float(p["d_safe"])))
    if res.soc_end < float(p["soc_reserve"]) - 1e-6:
        res.warnings.append("mission ends at %.0f percent state of charge, below the "
                            "%.0f percent reserve" % (100 * res.soc_end,
                                                      100 * float(p["soc_reserve"])))
    return res
