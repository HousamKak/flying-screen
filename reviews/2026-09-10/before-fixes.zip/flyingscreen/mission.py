"""
The mission: what the human does, and what the air does.

The human trajectory r_h(t) is the disturbance the vehicle must track.  The
desired screen position is r_d = r_h + d, an offset in front of the eyes,
and the desired yaw keeps the screen facing the person.

All trajectories are given analytically with their first and second
derivatives so the controller gets clean feedforward, which is what keeps
the tracking error honest rather than lag dominated.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple

import numpy as np

TWO_PI = 2.0 * math.pi


@dataclass
class HumanState:
    r: np.ndarray
    v: np.ndarray
    a: np.ndarray
    heading: float


class Human:
    """Base class: position, velocity and acceleration of the person."""

    name = "hover"

    def __init__(self, p: Dict[str, float]):
        self.p = p
        self.v_max = float(p["v_follow"])
        self.a_max = float(p["a_follow"])

    def __call__(self, t: float) -> HumanState:
        z = np.zeros(3)
        return HumanState(z.copy(), z.copy(), z.copy(), 0.0)


class Standing(Human):
    """A person standing still, with slow postural sway."""
    name = "standing"

    def __call__(self, t: float) -> HumanState:
        w = 2.0 * math.pi / 7.0
        A = 0.03
        r = np.array([A * math.sin(w * t), A * 0.6 * math.sin(0.77 * w * t), 0.0])
        v = np.array([A * w * math.cos(w * t),
                      A * 0.6 * 0.77 * w * math.cos(0.77 * w * t), 0.0])
        a = np.array([-A * w * w * math.sin(w * t),
                      -A * 0.6 * (0.77 * w) ** 2 * math.sin(0.77 * w * t), 0.0])
        return HumanState(r, v, a, 0.0)


class Pacing(Human):
    """
    Back and forth along x while keeping the screen in view, so the heading
    does not change.  This is reading while walking.
    """
    name = "pacing"
    turns = False

    def __init__(self, p: Dict[str, float]):
        super().__init__(p)
        # Peak speed = v_max, peak acceleration = a_max fixes both A and w.
        self.w = max(self.a_max / max(self.v_max, 1e-6), 1e-3)
        self.A = self.v_max / self.w

    def __call__(self, t: float) -> HumanState:
        A, w = self.A, self.w
        r = np.array([A * math.sin(w * t), 0.0, 0.0])
        v = np.array([A * w * math.cos(w * t), 0.0, 0.0])
        a = np.array([-A * w * w * math.sin(w * t), 0.0, 0.0])
        heading = 0.0
        if self.turns:
            # A real person turns over about a second rather than instantly,
            # so the heading is a smooth switch, not a sign test.  A
            # discontinuous heading would teleport the reference by twice the
            # standoff, which is a modelling artefact, not a control problem.
            k = 3.0 / max(self.v_max, 1e-6)
            heading = 0.5 * math.pi * (1.0 - math.tanh(k * v[0]))
        return HumanState(r, v, a, heading)


class TurnAround(Pacing):
    """
    The same pace, but the person turns around at each end.  The screen then
    has to swing through a half circle of radius equal to the standoff in
    about a second, which is by far the most demanding thing a following
    display is ever asked to do.
    """
    name = "turnaround"
    turns = True


class WalkLoop(Human):
    """A steady loop of the room, so the vehicle must also yaw around."""
    name = "walk_loop"

    def __init__(self, p: Dict[str, float]):
        super().__init__(p)
        self.R = max(self.v_max ** 2 / max(self.a_max, 1e-6), 0.5)
        self.w = self.v_max / self.R

    def __call__(self, t: float) -> HumanState:
        R, w = self.R, self.w
        c, s = math.cos(w * t), math.sin(w * t)
        r = np.array([R * c, R * s, 0.0])
        v = np.array([-R * w * s, R * w * c, 0.0])
        a = np.array([-R * w * w * c, -R * w * w * s, 0.0])
        return HumanState(r, v, a, math.atan2(v[1], v[0]))


class Jogging(Human):
    """Loop plus vertical bob: the case that stresses the tracking loop."""
    name = "jogging"

    def __init__(self, p: Dict[str, float]):
        super().__init__(p)
        self.base = WalkLoop(p)
        self.wb = TWO_PI * 1.5           # stride frequency
        self.Ab = 0.05

    def __call__(self, t: float) -> HumanState:
        h = self.base(t)
        r = h.r + np.array([0.0, 0.0, self.Ab * math.sin(self.wb * t)])
        v = h.v + np.array([0.0, 0.0, self.Ab * self.wb * math.cos(self.wb * t)])
        a = h.a + np.array([0.0, 0.0, -self.Ab * self.wb ** 2 * math.sin(self.wb * t)])
        return HumanState(r, v, a, h.heading)


class SitStand(Human):
    """Vertical steps: the screen has to follow eye height up and down."""
    name = "sit_stand"

    def __init__(self, p: Dict[str, float]):
        super().__init__(p)
        self.period = 40.0
        self.drop = 0.45
        self.tau = 1.2                    # smoothed step

    def __call__(self, t: float) -> HumanState:
        ph = (t % self.period) / self.period
        s = 0.5 * (1.0 + math.tanh((ph - 0.25) * self.period / self.tau)) \
            - 0.5 * (1.0 + math.tanh((ph - 0.75) * self.period / self.tau))
        # derivative of the tanh pair
        def dsech(u):
            return 1.0 / math.cosh(u) ** 2
        k = self.period / self.tau
        u1 = (ph - 0.25) * k
        u2 = (ph - 0.75) * k
        ds = 0.5 * k * (dsech(u1) - dsech(u2)) / self.period
        dds = 0.5 * k * k * (-2.0 * math.tanh(u1) * dsech(u1)
                             + 2.0 * math.tanh(u2) * dsech(u2)) / self.period ** 2
        r = np.array([0.0, 0.0, -self.drop * s])
        v = np.array([0.0, 0.0, -self.drop * ds])
        a = np.array([0.0, 0.0, -self.drop * dds])
        return HumanState(r, v, a, 0.0)


HUMANS: Dict[str, Any] = {
    "standing": Standing,
    "pacing": Pacing,
    "turnaround": TurnAround,
    "walk_loop": WalkLoop,
    "jogging": Jogging,
    "sit_stand": SitStand,
}


def make_human(p: Dict[str, float], kind: str = "pacing") -> Human:
    cls = HUMANS.get(kind, Pacing)
    return cls(p)


def desired_position(p: Dict[str, float], human: Human, t: float) -> np.ndarray:
    """
    Where the *vehicle centroid* must go.

    The standoff is specified to the screen, because that is what the user
    cares about. What the controller flies is the rotor centroid, which sits
    a boom length further away when the display is cantilevered forward.
    Confusing the two puts the rotors exactly one boom length too close to
    the person.
    """
    h = human(t)
    d = float(p["standoff"]) + float(p.get("screen_forward", 0.0))
    psi = h.heading
    return h.r + np.array([d * math.cos(psi), d * math.sin(psi),
                           float(p["standoff_z"])])


class ReferenceGovernor:
    """
    Rate and acceleration limited reference.

    Tracking a person's face rigidly is the wrong specification: when they
    turn around, holding a fixed standoff in front of the eyes demands a
    half circle of radius 0.7 m in about a second, which is over 10 m/s^2
    and whips a 1.5 kg object past their head.  A real product lets the
    screen fall behind and catch up.

    This is a second order reference filter, the standard trajectory
    smoother: the governed reference chases the raw one under explicit
    speed and acceleration caps, so what reaches the controller is always
    something the aircraft can actually fly.

        a = clip(kp (r_raw - r_g) + kd (v_raw - v_g), a_max)
        v_g = clip(v_g + a dt, v_max)

    The caps are the product decision; everything downstream is unchanged.
    """

    def __init__(self, p: Dict[str, float], r0: np.ndarray,
                 v_max: float = 2.5, a_max: float = 2.5,
                 kp: float = 16.0, kd: float = 8.0):
        # The filter itself must be fast (kp, kd set about 4 rad/s, critically
        # damped) so that it is transparent during ordinary following and
        # only intervenes when the acceleration cap actually bites. A slow
        # filter would add a steady lag on every curved path, which is a
        # different and much worse behaviour than yielding during a turn.
        self.v_max = float(v_max)
        self.a_max = float(a_max)
        self.kp = kp
        self.kd = kd
        self.r = np.asarray(r0, dtype=float).copy()
        self.v = np.zeros(3)
        self.a = np.zeros(3)
        self.blocked = False

    def step(self, r_raw: np.ndarray, v_raw: np.ndarray, dt: float,
             keep_out: Optional[Tuple[np.ndarray, float]] = None) -> None:
        a = self.kp * (np.asarray(r_raw) - self.r) + self.kd * (np.asarray(v_raw) - self.v)
        n = float(np.linalg.norm(a))
        if n > self.a_max:
            a *= self.a_max / n
        self.a = a
        self.v = self.v + a * dt
        n = float(np.linalg.norm(self.v))
        if n > self.v_max:
            self.v *= self.v_max / n
        self.r = self.r + self.v * dt

        # Keep-out sphere around the person's head.
        #
        # Rate limiting alone is not safe. On a curved path the acceleration
        # cap makes the governed reference cut the corner, and the governor
        # has no idea where the person is, so the very thing that stops the
        # screen whipping around a head can steer it through one. Project the
        # reference back out of the sphere and kill the inward velocity.
        if keep_out is not None:
            centre, radius = keep_out
            d = self.r - np.asarray(centre, dtype=float)
            dist = float(np.linalg.norm(d))
            if dist < radius:
                n_hat = d / dist if dist > 1e-9 else np.array([1.0, 0.0, 0.0])
                self.r = np.asarray(centre, dtype=float) + n_hat * radius
                inward = float(np.dot(self.v, n_hat))
                if inward < 0.0:
                    self.v -= inward * n_hat
                self.blocked = True
            else:
                self.blocked = False


def reference(p: Dict[str, float], human: Human, t: float,
              h_fd: float = 1e-3) -> Dict[str, Any]:
    """
    Desired screen state with true feedforward.

    The offset rotates with the heading, so a turning person generates a
    genuine centripetal demand on the vehicle.  Differentiating the full
    r_d(t) rather than only the human position is what removes the standing
    lag error on a curved path.
    """
    h = human(t)
    r0 = desired_position(p, human, t)
    rp = desired_position(p, human, t + h_fd)
    rm = desired_position(p, human, t - h_fd)
    v = (rp - rm) / (2.0 * h_fd)
    a = (rp - 2.0 * r0 + rm) / (h_fd * h_fd)
    psi = h.heading
    return dict(r=r0, v=v, a=a, yaw=psi + math.pi, human=h.r, heading=psi)


# ---------------------------------------------------------------------------
# Wind
# ---------------------------------------------------------------------------
class Wind:
    """Mean wind plus a band-limited Ornstein-Uhlenbeck gust on each axis."""

    def __init__(self, p: Dict[str, float], t_end: float, dt: float = 0.02,
                 seed: int = 12345):
        self.mean = np.array([float(p["wind_mean"]), 0.0, 0.0])
        sigma = float(p["wind_gust"])
        self.dt = dt
        n = max(int(t_end / dt) + 2, 2)
        rng = np.random.default_rng(seed)
        tau = max(float(p["gust_tau"]), 1e-3)
        g = np.zeros((n, 3))
        if sigma > 0.0:
            a = math.exp(-dt / tau)
            s = sigma * math.sqrt(1.0 - a * a)
            for i in range(1, n):
                g[i] = a * g[i - 1] + s * rng.standard_normal(3)
            g[:, 2] *= 0.5                # vertical gusts are weaker
        self.g = g

    def __call__(self, t: float) -> np.ndarray:
        i = t / self.dt
        i0 = int(i)
        if i0 >= len(self.g) - 1:
            return self.mean + self.g[-1]
        f = i - i0
        return self.mean + (1.0 - f) * self.g[i0] + f * self.g[i0 + 1]


MISSIONS = list(HUMANS.keys())
