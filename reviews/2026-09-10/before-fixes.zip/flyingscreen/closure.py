"""
Stage 6: close the battery loop around the real simulation.

    guess m_bat -> gross mass -> simulate the mission -> energy actually used
                -> required m_bat -> repeat

If the sequence settles, the design exists.  If it runs away, the mass
spiral has been discovered computationally rather than assumed.

The expensive part is the simulation, so the loop is structured to need
exactly one simulation per outer iteration: the inner mass closure (frame
and propulsion mass as functions of gross mass) is algebraic and converges
in a few cheap passes.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from . import components as comp
from . import sizing
from .params import derived
from .simulate import simulate_flight


def gross_mass_for_battery(p: Dict[str, float], m_bat: float,
                           iters: int = 60) -> float:
    """
    Solve m = m_fix + m_frame(m) + m_prop(m) + m_bat for a fixed battery.

    Both submodels are close to linear in m, so plain iteration converges
    geometrically and needs no derivatives.
    """
    d = derived(p)
    N = float(p["N_rotors"])
    m = d.m_fix + m_bat
    for _ in range(iters):
        pr = comp.propulsion(p, m)
        arm = comp.arm_structure(
            p, m, m_tip=pr.m_motor_each + (pr.m_esc + pr.m_props) / N)
        m_new = d.m_fix + arm.m_frame + pr.m_prop_total + m_bat
        if abs(m_new - m) < 1e-10 * max(1.0, m):
            return m_new
        m = m_new
    return m


@dataclass
class ClosureRun:
    converged: bool
    diverged: bool
    status: str
    reason: str = ""
    trace: List[Dict[str, float]] = field(default_factory=list)
    m: float = 0.0
    m_bat: float = 0.0
    P_mean: float = 0.0
    E_mission: float = 0.0
    overhead: float = 1.0
    sim: Dict[str, Any] = field(default_factory=dict)
    design: Dict[str, Any] = field(default_factory=dict)
    analytic: Dict[str, Any] = field(default_factory=dict)
    warnings: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return dict(self.__dict__)


def close_with_simulation(p: Dict[str, float], mission_kind: str = "pacing",
                          t_window: float = 12.0, dt: float = 0.004,
                          m_bat0: Optional[float] = None, max_iter: int = 8,
                          tol: float = 2e-3, relax: float = 1.0,
                          cap_ratio: float = 60.0,
                          keep_telemetry: bool = True,
                          governor: Optional[Dict[str, float]] = None) -> ClosureRun:
    """
    The residual pair from the derivation,

        R1 = m - (m_fix + m_str + m_prop + m_bat)
        R2 = e_b m_bat - E_mission(m, p, u)

    driven to zero.  R1 is solved exactly at every step by
    gross_mass_for_battery, so the outer loop only has to drive R2.
    """
    d = derived(p)
    t_f = float(p["t_f"])
    analytic = sizing.solve_fixed_area(p)

    if m_bat0 is None:
        m_bat0 = analytic.m_bat if analytic.feasible and analytic.m_bat > 0 else \
            max(0.25, d.m_fix)
    m_bat = float(m_bat0)
    cap = cap_ratio * max(m_bat0, 1e-3)

    trace: List[Dict[str, float]] = []
    last_sim = None
    warnings: List[str] = []
    status = "slow"
    converged = diverged = False
    reason = ""
    prev = None          # (m_bat, gap) of the previous iterate, for the secant step

    for it in range(max_iter):
        m = gross_mass_for_battery(p, m_bat)
        sim = simulate_flight(p, m, m_bat=m_bat, mission_kind=mission_kind,
                              t_window=t_window, dt=dt, governor=governor)
        if not sim.ok:
            return ClosureRun(False, False, "failed", sim.reason,
                              trace=trace, m=m, m_bat=m_bat,
                              analytic=analytic.to_dict())
        last_sim = sim
        E_mission = sim.P_mean * t_f
        reserve = min(max(float(p["soc_reserve"]), 0.0), 0.9)
        m_bat_energy = E_mission / (d.e_b * (1.0 - reserve))
        m_bat_power = sim.P_peak / float(p["p_b_w_kg"])
        m_bat_req = max(m_bat_energy, m_bat_power)

        trace.append(dict(iteration=it, m=m, m_bat=m_bat,
                          m_bat_required=m_bat_req, P_mean=sim.P_mean,
                          E_mission=E_mission, overhead=sim.overhead,
                          residual=d.e_b * m_bat - E_mission,
                          e_track_rms=sim.e_track_rms))

        if abs(m_bat_req - m_bat) < tol * max(1.0, m_bat):
            converged = True
            status = "converged"
            m_bat = m_bat_req
            break
        if m_bat_req > cap or not math.isfinite(m_bat_req):
            diverged = True
            status = "diverging"
            reason = ("battery mass ran away past %.1f kg: the energy the mission "
                      "needs grows faster than the mass added to carry it" % cap)
            break

        # Plain iteration on this map contracts only as fast as the battery
        # mass fraction, which near the fold is barely at all.  A secant step
        # on the same residual costs no extra simulation and converges
        # superlinearly, so the loop usually finishes in three or four flights
        # instead of eight.
        gap = m_bat_req - m_bat
        step = relax * gap
        if prev is not None:
            m_prev, gap_prev = prev
            dg = gap - gap_prev
            dm = m_bat - m_prev
            if abs(dg) > 1e-12 and abs(dm) > 1e-12:
                secant = -gap * dm / dg
                # Only trust it while it stays a sane, same-direction move.
                if math.isfinite(secant) and secant * gap > 0 and \
                        abs(secant) < 6.0 * abs(gap) + 1e-9:
                    step = secant
        prev = (m_bat, gap)
        m_bat = max(m_bat + step, 1e-4)

    if not converged and not diverged and len(trace) >= 3:
        d1 = trace[-2]["m_bat_required"] - trace[-2]["m_bat"]
        d2 = trace[-1]["m_bat_required"] - trace[-1]["m_bat"]
        if abs(d1) > 1e-12 and abs(d2 / d1) >= 1.0 and abs(d2) > tol:
            diverged = True
            status = "diverging"
            reason = "the fixed point map is expanding: successive corrections grow"

    m = gross_mass_for_battery(p, m_bat)
    sim = last_sim
    if converged:
        sim = simulate_flight(p, m, m_bat=m_bat, mission_kind=mission_kind,
                              t_window=t_window, dt=dt, governor=governor)
    bd = comp.breakdown(p, m, m_bat=m_bat)
    warnings.extend(bd.warnings)
    if sim is not None:
        warnings.extend(sim.warnings)

    sim_dict: Dict[str, Any] = {}
    if sim is not None:
        sim_dict = sim.to_dict()
        if not keep_telemetry:
            sim_dict.pop("telemetry", None)
            sim_dict.pop("trajectory", None)
            sim_dict.pop("t", None)

    return ClosureRun(
        converged=converged, diverged=diverged, status=status, reason=reason,
        trace=trace, m=m, m_bat=m_bat,
        P_mean=sim.P_mean if sim else 0.0,
        E_mission=(sim.P_mean * t_f) if sim else 0.0,
        overhead=sim.overhead if sim else 1.0,
        sim=sim_dict, design=bd.to_dict(), analytic=analytic.to_dict(),
        warnings=warnings,
    )
